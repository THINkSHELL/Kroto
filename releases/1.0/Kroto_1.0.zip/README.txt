Extract the contents of this package in your Grasshopper Settings folder (usually %HOME%\AppData\Roaming\Grasshopper\ if you are on Windows 7 and later).
You can also find this folder in the Grasshopper Menu: File > Special Folders > Settings Folder.

The files should be extracted to their respective folders automatically.